install.packages("h2o")
library(h2o) 
h2o.init() 
iris.hex <- as.h2o(iris) 
iris.dl <- h2o.deeplearning(x = 1:4, y = 5, training_frame = iris.hex, hidden = c(10,10))

avnnet.train.nnet.tunnable


# now make a prediction 
predictions <- h2o.predict(iris.dl, iris.hex)
predictions<-as.data.frame(predictions)
# count the precision
table(iris$Species , predictions$predict)


#----------------
par(mfrow=c(1,2))
data<-c(1,1,1,11,3,3,3,34,45,43,56,3,3,3)

plot(density(data),col="blue",lwd=2)
hist(data,breaks=50)

 # x <- log(rgamma(150,5))
# df <- approxfun(density(x))
# plot(density(x))
# xnew <- c(1,10,60)
# points(xnew,df(xnew),col=2)

